# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['whenareyou']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.27,<3.0', 'timezonefinder>=5.2,<6.0']

setup_kwargs = {
    'name': 'whenareyou',
    'version': '0.5.0',
    'description': 'Gets the time zone name of any location in the world.',
    'long_description': None,
    'author': 'Florian Obersteiner',
    'author_email': 'f.obersteiner@posteo.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7',
}


setup(**setup_kwargs)
