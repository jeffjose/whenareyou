from whenareyou.whenareyou import whenareyou, whenareyou_IATA
from whenareyou._version import __version__

# https://docs.python.org/3/tutorial/modules.html#importing-from-a-package
# determines which objects will be imported with "import *"
__all__ = ("whenareyou", "whenareyou_IATA")